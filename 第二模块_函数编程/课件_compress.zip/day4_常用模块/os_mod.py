import os

print(__file__)  # 打印当前脚本所在的路径，包含文件名

print(os.path.abspath(__file__))
