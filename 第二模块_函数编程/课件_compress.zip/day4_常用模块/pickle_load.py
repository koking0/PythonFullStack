import pickle


f = open("game.pkl","rb")

print( pickle.load(f) )
print( pickle.load(f) )
print( pickle.load(f) )

