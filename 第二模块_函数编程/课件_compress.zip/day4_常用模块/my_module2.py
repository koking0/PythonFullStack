
import my_module
import sys


print(sys.path)

my_module.sayhi("jack")