
import my_module

my_module.sayhi("小猿圈")