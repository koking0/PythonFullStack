from django.apps import AppConfig


class ApelandWebConfig(AppConfig):
    name = 'apeland_web'
