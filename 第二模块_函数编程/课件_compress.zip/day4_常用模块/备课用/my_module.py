

print("my first module")


def sayhi(name):
    print("Hello {0}, thanks for invoking me .".format(name))


