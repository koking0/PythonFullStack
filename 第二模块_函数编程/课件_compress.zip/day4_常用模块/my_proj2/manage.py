

from apeland_web import  views

print("---rum my_proj2----")