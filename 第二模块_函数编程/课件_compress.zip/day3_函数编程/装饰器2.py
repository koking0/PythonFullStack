def plus(n):
    return n + 1


plus2 = lambda x: x + 1

calc = plus

print(calc(10))
