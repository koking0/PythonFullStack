


#
# a = 0
# b = 1
#
# count = 0
# while count < 20:
#     tmp = a
#     a = b
#     b = tmp + b
#     print(b)
#     count += 1



#
#
# def fib(n):
#     a = 0
#     b = 1
#
#     count = 0
#     while count < n:
#         tmp = a
#         a =  b
#         b = tmp +b
#         count += 1
#         print(a,b )
#
#
# fib(20)