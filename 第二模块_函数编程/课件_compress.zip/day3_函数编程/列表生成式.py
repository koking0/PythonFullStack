#
# a = [1,3,4,6,7,7,8,9,11]
#
# for index,i in enumerate(a):
#     #print(index,i)
#     a[index] +=1
#
#
# print(a)

a = [1,3,4,6,7,7,8,9,11]

# a = list(map(lambda x:x+1,a))
# print(a)

a = [i**i for i in a ]
print(a)
