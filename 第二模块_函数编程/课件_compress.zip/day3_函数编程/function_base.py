
#
# def sayhi():#函数名
#     print("Hello, I'm nobody!")
#
#
# sayhi() #调用函数
# sayhi() #调用函数
# sayhi() #调用函数

# def calculate(x,y):
#
#     res = x**y
#     #print(res)
#     return res # 返回值， 意味着函数的中止
#     print('大')
#
#
# n = calculate(5,8)
# print(n)

