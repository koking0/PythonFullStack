
#
# def test():
#
#     return 1,2,3,4,5
#
# print(test())

#name = "Alex"

# def change():
#     #name = "金角大王" # 局部变量
#     global name # 在函数内部声明(创建)一个全局变量
#     name = "hahah"
#     age = 22
#     print(name)
#     print(locals())
#     print(globals())
#
# change()
#
# print(name)
#



names = ["alex","jack"]

def change():

    names = 3
    #names.append("Racheal")
    #names.append("Racheal")

change()
print(names)