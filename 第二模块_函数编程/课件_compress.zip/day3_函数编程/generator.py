
# 生成器 generator
#
# for i in range(100000):
#     print(i)
#
#     if i > 100:
#         break

count = 0
while count < 1000000:
    print(count)
    count += 1
    if count > 100:
        break