#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time     : 2020/1/31 12:06
# @File     : server.py
# ----------------------------------------------
# ☆ ☆ ☆ ☆ ☆ ☆ ☆ 
# >>> Author    : Alex
# >>> QQ        : 2426671397
# >>> Mail      : alex18812649207@gmail.com
# >>> Github    : https://github.com/koking0
# ☆ ☆ ☆ ☆ ☆ ☆ ☆
from bin import ftp_server

if __name__ == '__main__':
    ftp_server.main()
